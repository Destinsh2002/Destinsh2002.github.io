from pymongo import ASCENDING, DESCENDING, MongoClient
from pymongo.errors import OperationFailure, PyMongoError


class AnimalShelter:
    """CRUD operations for the AAC animals collection."""

    def __init__(self, username="aacuser", password="Password123",
                 host="localhost", port=27017, db_name="aac", collection="animals"):
        uri = f"mongodb://{username}:{password}@{host}:{port}/{db_name}?authSource={db_name}"

        try:
            self.client = MongoClient(uri, serverSelectionTimeoutMS=5000)
            # This makes sure the connection is actually working before moving on.
            self.client.admin.command("ping")
        except OperationFailure:
            # Some school environments do not have authentication turned on.
            self.client = MongoClient(host=host, port=port, serverSelectionTimeoutMS=5000)

        self.database = self.client[db_name]
        self.collection = self.database[collection]
        self._create_indexes()

    def _create_indexes(self):
        """Create indexes used by the dashboard searches and sorting."""
        try:
            # These are the fields that get searched the most in the dashboard.
            self.collection.create_index([("animal_id", ASCENDING)], unique=False)
            self.collection.create_index([("breed", ASCENDING)])
            self.collection.create_index([("name", ASCENDING)])
            self.collection.create_index([("sex_upon_outcome", ASCENDING)])
            self.collection.create_index([("age_upon_outcome_in_weeks", ASCENDING)])
        except PyMongoError:
            # The dashboard can still run if an index cannot be made.
            pass

    @staticmethod
    def _valid_dictionary(value):
        return isinstance(value, dict) and len(value) > 0

    def create(self, data):
        """Insert one document and return True when it was added."""
        if not self._valid_dictionary(data):
            return False

        try:
            self.collection.insert_one(data)
            return True
        except PyMongoError:
            return False

    def read(self, query=None, sort_field=None, sort_direction=ASCENDING, limit=0):
        """Read documents with optional sorting and a result limit."""
        if query is not None and not isinstance(query, dict):
            return []

        query = query or {}
        cursor = self.collection.find(query)

        if sort_field:
            direction = DESCENDING if sort_direction == DESCENDING else ASCENDING
            cursor = cursor.sort(sort_field, direction)

        if isinstance(limit, int) and limit > 0:
            cursor = cursor.limit(limit)

        try:
            return list(cursor)
        except PyMongoError:
            return []

    def advanced_search(self, rescue_type=None, breed=None, name=None, sex=None,
                        minimum_age_weeks=None, maximum_age_weeks=None,
                        sort_field="name", descending=False, limit=250):
        """Build a MongoDB query from the optional dashboard search values."""
        query = {}

        rescue_breeds = {
            "water_rescue": [
                "Labrador Retriever Mix", "Chesapeake Bay Retriever",
                "Newfoundland", "Labrador Retriever"
            ],
            "mountain_wilderness_rescue": [
                "German Shepherd", "Alaskan Malamute", "Old English Sheepdog",
                "Siberian Husky", "Rottweiler"
            ],
            "disaster_individual_tracking": [
                "Doberman Pinscher", "German Shepherd", "Golden Retriever",
                "Bloodhound", "Rottweiler"
            ]
        }

        if rescue_type in rescue_breeds:
            query["animal_type"] = "Dog"
            query["breed"] = {"$in": rescue_breeds[rescue_type]}

        # Regex lets the user enter only part of the breed or animal name.
        if isinstance(breed, str) and breed.strip():
            query["breed"] = {"$regex": breed.strip(), "$options": "i"}

        if isinstance(name, str) and name.strip():
            query["name"] = {"$regex": name.strip(), "$options": "i"}

        if isinstance(sex, str) and sex.strip() and sex != "All":
            query["sex_upon_outcome"] = {"$regex": f"^{sex.strip()}", "$options": "i"}

        age_query = {}
        if isinstance(minimum_age_weeks, (int, float)) and minimum_age_weeks >= 0:
            age_query["$gte"] = minimum_age_weeks
        if isinstance(maximum_age_weeks, (int, float)) and maximum_age_weeks >= 0:
            age_query["$lte"] = maximum_age_weeks
        if age_query:
            query["age_upon_outcome_in_weeks"] = age_query

        direction = DESCENDING if descending else ASCENDING
        allowed_sort_fields = {
            "name", "breed", "animal_id", "sex_upon_outcome",
            "age_upon_outcome_in_weeks"
        }
        if sort_field not in allowed_sort_fields:
            sort_field = "name"

        return self.read(query, sort_field, direction, limit)

    def update(self, query, new_values):
        """Update matching documents and return the number changed."""
        if not self._valid_dictionary(query) or not self._valid_dictionary(new_values):
            return 0

        # The _id field should not be changed after MongoDB creates it.
        clean_values = {key: value for key, value in new_values.items() if key != "_id"}
        if not clean_values:
            return 0

        try:
            result = self.collection.update_many(query, {"$set": clean_values})
            return result.modified_count
        except PyMongoError:
            return 0

    def delete(self, query):
        """Delete matching documents and return the number removed."""
        # Requiring a query prevents deleting the full collection by mistake.
        if not self._valid_dictionary(query):
            return 0

        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except PyMongoError:
            return 0
