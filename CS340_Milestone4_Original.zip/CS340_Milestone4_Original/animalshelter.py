from pymongo import MongoClient
from pymongo.errors import OperationFailure

class AnimalShelter:
    """CRUD operations for AAC animals collection."""

    def __init__(self, username="aacuser", password="Password123",
                 host="localhost", port=27017, db_name="aac", collection="animals"):
        uri = f"mongodb://{username}:{password}@{host}:{port}/{db_name}?authSource={db_name}"
        try:
            self.client = MongoClient(uri, serverSelectionTimeoutMS=5000)
            # force a round-trip to trigger auth errors if any:
            self.client.admin.command("ping")
        except OperationFailure:
            # fallback if access control is disabled in this environment
            self.client = MongoClient(host=host, port=port, serverSelectionTimeoutMS=5000)

        self.database = self.client[db_name]
        self.collection = self.database[collection]

    def create(self, data):
        if data:
            self.collection.insert_one(data)
            return True
        return False

    def read(self, query=None):
        query = query or {}
        return list(self.collection.find(query))

    def update(self, query, new_values):
        result = self.collection.update_many(query, {"$set": new_values})
        return result.modified_count

    def delete(self, query):
        result = self.collection.delete_many(query)
        return result.deleted_count
