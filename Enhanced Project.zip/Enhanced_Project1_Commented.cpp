#include <iostream>
#include <string>
#include <vector>
#include <limits>
#include <algorithm>

using namespace std;

// Stores all information for one customer in one place.
// Enhancement:
// I changed the customer data to a struct.
// This keeps all of the information together
// and makes the code easier to work with.
struct Customer
{
    int id;
    string name;
    int serviceChoice;
};

const string USERNAME = "admin";
const string PASSWORD = "123";

// Clears bad input so the program does not get stuck.
void ClearInput()
{
    cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
}

// Gets a number from the user and checks the allowed range.
// Enhancement:
// This function validates user input.
// It keeps bad values from causing problems.
int GetValidNumber(const string& prompt, int minimum, int maximum)
{
    int value;

    while (true)
    {
        cout << prompt;

        if (cin >> value && value >= minimum && value <= maximum)
        {
            ClearInput();
            return value;
        }

        cout << "Invalid input. Please enter a number between "
             << minimum << " and " << maximum << "." << endl;

        ClearInput();
    }
}

// Checks both the username and password.
bool CheckUserPermissionAccess()
{
    string user;
    string pass;

    cout << "Enter your username: " << endl;
    cin >> user;

    cout << "Enter your password: " << endl;
    cin >> pass;

    ClearInput();

    return user == USERNAME && pass == PASSWORD;
}

// Converts a service number into a name that is easier to read.
string GetServiceName(int serviceChoice)
{
    if (serviceChoice == 1)
    {
        return "Brokerage";
    }

    return "Retirement";
}

// Displays one customer record.
void DisplayCustomer(const Customer& customer)
{
    cout << customer.id << ". "
         << customer.name
         << " selected "
         << GetServiceName(customer.serviceChoice)
         << " (option " << customer.serviceChoice << ")"
         << endl;
}

// Uses one loop to display every customer in the vector.
void DisplayInfo(const vector<Customer>& customers)
{
    cout << endl;
    cout << "Client's Name     Service Selected" << endl;

    for (const Customer& customer : customers)
    {
        DisplayCustomer(customer);
    }

    cout << endl;
}

// Searches the vector for a customer ID.
// Returns the customer's position or -1 when they are not found.
// Enhancement:
// Added a search function that looks for
// a customer by their ID.
int FindCustomerById(const vector<Customer>& customers, int customerId)
{
    for (size_t i = 0; i < customers.size(); i++)
    {
        if (customers[i].id == customerId)
        {
            return static_cast<int>(i);
        }
    }

    return -1;
}

// Changes text to lowercase so name searches are not case sensitive.
string ToLowerCase(string text)
{
    transform(text.begin(), text.end(), text.begin(),
        [](unsigned char character)
        {
            return static_cast<char>(tolower(character));
        });

    return text;
}

// Searches for all customers whose names contain the entered text.
// Enhancement:
// This lets the user search using part of
// a customer's name.
void SearchCustomerByName(const vector<Customer>& customers)
{
    string searchText;
    bool found = false;

    cout << "Enter all or part of the customer's name: ";
    getline(cin, searchText);

    string lowerSearchText = ToLowerCase(searchText);

    cout << endl;
    cout << "Search Results" << endl;

    for (const Customer& customer : customers)
    {
        string lowerCustomerName = ToLowerCase(customer.name);

        if (lowerCustomerName.find(lowerSearchText) != string::npos)
        {
            DisplayCustomer(customer);
            found = true;
        }
    }

    if (!found)
    {
        cout << "No customers matched that name." << endl;
    }

    cout << endl;
}

// Lets the user choose between searching by ID or name.
// Enhancement:
// Added a new menu option that allows
// searching by ID or by name.
void SearchCustomer(const vector<Customer>& customers)
{
    cout << endl;
    cout << "SEARCH by customer ID (enter 1)" << endl;
    cout << "SEARCH by customer name (enter 2)" << endl;

    int searchChoice = GetValidNumber("Enter your choice: ", 1, 2);

    if (searchChoice == 1)
    {
        int customerId = GetValidNumber(
            "Enter the customer ID: ",
            1,
            static_cast<int>(customers.size())
        );

        int customerIndex = FindCustomerById(customers, customerId);

        if (customerIndex != -1)
        {
            cout << endl;
            cout << "Customer Found" << endl;
            DisplayCustomer(customers[customerIndex]);
            cout << endl;
        }
        else
        {
            cout << "Customer not found." << endl;
        }
    }
    else
    {
        SearchCustomerByName(customers);
    }
}

// Updates one customer without a long group of if and else statements.
// Enhancement:
// I removed the long if/else chain.
// The program now finds the customer first
// then updates the service.
void ChangeCustomerChoice(vector<Customer>& customers)
{
    int customerId = GetValidNumber(
        "Enter the number of the client that you wish to change: ",
        1,
        static_cast<int>(customers.size())
    );

    int customerIndex = FindCustomerById(customers, customerId);

    if (customerIndex == -1)
    {
        cout << "Customer not found." << endl;
        return;
    }

    cout << "Current service: "
         << GetServiceName(customers[customerIndex].serviceChoice)
         << endl;

    int newService = GetValidNumber(
        "Enter the new service choice (1 = Brokerage, 2 = Retirement): ",
        1,
        2
    );

    customers[customerIndex].serviceChoice = newService;

    cout << customers[customerIndex].name
         << " was updated to "
         << GetServiceName(newService)
         << "." << endl;
    cout << endl;
}

int main()
{
    // A vector makes it easier to store, search, and update customer records.
    // Enhancement:
    // I now store every customer in a vector.
    // This lets me loop through the data instead
    // of having lots of repeated code.
    vector<Customer> customers =
    {
        {1, "Bob Jones", 1},
        {2, "Sarah Davis", 2},
        {3, "Amy Friendly", 1},
        {4, "Johnny Smith", 1},
        {5, "Carol Spears", 2}
    };

    cout << "Created by Destin Shaffer" << endl;
    cout << "Hello! Welcome to our Investment Company" << endl;

    int attempts = 0;
    bool accessGranted = false;

    // Limits login attempts instead of allowing the loop to run forever.
    // Enhancement:
    // Login attempts are now limited.
    // This is better than allowing unlimited tries.
    while (!accessGranted && attempts < 3)
    {
        accessGranted = CheckUserPermissionAccess();

        if (!accessGranted)
        {
            attempts++;
            cout << "Invalid username or password. Please try again." << endl;
        }
    }

    if (!accessGranted)
    {
        cout << "Too many failed login attempts. Exiting program." << endl;
        return 0;
    }

    int choice = 0;

    while (choice != 4)
    {
        cout << "What would you like to do?" << endl;
        cout << "DISPLAY the client list (enter 1)" << endl;
        cout << "CHANGE a client's choice (enter 2)" << endl;
        cout << "SEARCH for a client (enter 3)" << endl;
        cout << "EXIT the program (enter 4)" << endl;

        choice = GetValidNumber("Enter your choice: ", 1, 4);

        if (choice == 1)
        {
            DisplayInfo(customers);
        }
        else if (choice == 2)
        {
            ChangeCustomerChoice(customers);
        }
        else if (choice == 3)
        {
            SearchCustomer(customers);
        }
    }

    cout << "Program closed." << endl;

    return 0;
}
