#include <iostream>
#include <string>

using namespace std;

string username;
string password = "123";

string name1 = "Bob Jones";
string name2 = "Sarah Davis";
string name3 = "Amy Friendly";
string name4 = "Johnny Smith";
string name5 = "Carol Spears";

int num1 = 1;
int num2 = 2;
int num3 = 1;
int num4 = 1;
int num5 = 2;

int CheckUserPermissionAccess()
{
    string user;
    string pass;

    cout << "Enter your username: " << endl;
    cin >> user;

    cout << "Enter your password: " << endl;
    cin >> pass;

    if (pass == password)
    {
        return 1;
    }

    return 2;
}

void DisplayInfo()
{
    cout << "Client's Name     Service Selected" << endl;

    cout << "1. " << name1 << " selected option " << num1 << endl;
    cout << "2. " << name2 << " selected option " << num2 << endl;
    cout << "3. " << name3 << " selected option " << num3 << endl;
    cout << "4. " << name4 << " selected option " << num4 << endl;
    cout << "5. " << name5 << " selected option " << num5 << endl;
}

void ChangeCustomerChoice()
{
    int choice;
    int newservice;

    cout << "Enter the number of the client that you wish to change" << endl;
    cin >> choice;

    cout << "Please enter the client's new service choice (1 = Brokerage, 2 = Retirement)" << endl;
    cin >> newservice;

    if (choice == 1)
        num1 = newservice;
    else if (choice == 2)
        num2 = newservice;
    else if (choice == 3)
        num3 = newservice;
    else if (choice == 4)
        num4 = newservice;
    else if (choice == 5)
        num5 = newservice;
}

int main()
{
    cout << "Created by Destin Shaffer" << endl;
    cout << "Hello! Welcome to our Investment Company" << endl;

    int answer = 0;

    while (answer != 1)
    {
        answer = CheckUserPermissionAccess();

        if (answer != 1)
        {
            cout << "Invalid Password. Please try again" << endl;
        }
    }

    int choice = 0;

    while (choice != 3)
    {
        cout << "What would you like to do?" << endl;
        cout << "DISPLAY the client list (enter 1)" << endl;
        cout << "CHANGE a client's choice (enter 2)" << endl;
        cout << "Exit the program.. (enter 3)" << endl;

        cin >> choice;

        cout << "You chose " << choice << endl;

        if (choice == 1)
        {
            DisplayInfo();
        }
        else if (choice == 2)
        {
            ChangeCustomerChoice();
        }
    }

    return 0;
}
